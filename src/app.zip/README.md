# Express Hello Word

```npm install```

```npm start```

